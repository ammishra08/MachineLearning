from flask import Flask, jsonify, Response, request, render_template, redirect
import pymongo

app = Flask(__name__)

# Connect to  mongoDB Database
try:
    client = pymongo.MongoClient("mongodb://localhost:27017")
    client.server_info()
    db = client['users']
    collection = db['userscollection']
except:
    print("Error Cannot Connect to MongoDB")

# Get method to response the courses as a json type
@app.route('/', methods = ["GET","POST"])
def create_products():
    if request.method == "POST":
        product = { 
            "productid" : request.form['productid'],
            "product" : request.form['product'],
            "desc" : request.form['desc']
        }
        
        collection.insert_one(product)
    
    # Display all documents
    allProducts = list(collection.find())
    return render_template('index.html', allProducts = allProducts)

if __name__ == "__main__":
    # Response will show the debug page with exact error
    app.run(debug=True, port=8000)